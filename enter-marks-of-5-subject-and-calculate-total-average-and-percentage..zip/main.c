#include<stdio.h>
void main()
{
    float m,e,p,c,com;

    printf("enter marks of maths:");
    scanf("%f",&m);
    
    printf("enter marks of english:");
    scanf("%f",&e);
    
    printf("enter marks of physics:");
    scanf("%f",&p);
    
    printf("enter marks ofchemistry :");
    scanf("%f",&c);
    
    printf("enter marks of compuer :");
    scanf("%f",&com);
    
    printf("total=%f\n",m+e+p+c+com);
    printf("avg=%f\n",(m+e+p+c+com)/5);
    printf("percentage=%f\n",((m+e+p+c+com)/5)*100); 
    
    
}