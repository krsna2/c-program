#include <stdio.h>

void main()
{
    float length;
    printf("enter the length in centimeter=");
scanf("%f",&length);
 
 printf("length in meter=%f\n",length/100);
 printf("length in kilometer=%f\n",length/100000);
}
