
#include <stdio.h>

int main()
{
    int j,i,rows;
    printf("enter the no. of rows:");
    scanf("%d",&rows);
    
    for(i=1;i<=rows;i++)
    {
        for(j=1;j<=i;j++)
        {
        printf("*");
        }
    printf("\n");  
    }
    
}
