#include <stdio.h>
int main()
{
int a,b;
int mod;

printf("enter the first no.:");
scanf("%d",&a);
printf("enter the second no.:");
scanf("%d",&b);
mod=a%b;

printf("the mod is=%d\n",mod);
}