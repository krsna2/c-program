
#include <stdio.h>

int main()
{
    int n,i,c=0;
    printf("entre the no.:");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        if(n%i==0)
       {
           c++;
           
       }
    }
    if(c==2)
    {
        printf("the given no.is prime");
    }
    else
    {
        printf("the given no. is not a prime no.");
    }
}


