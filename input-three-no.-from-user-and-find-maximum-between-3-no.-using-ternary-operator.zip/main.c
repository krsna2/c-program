
#include <stdio.h>

int main()
{
int a,b,c,big;
printf("enter three no.");
scanf("%d %d %d",&a,&b,&c);
big=a>b?(a>c?a:c):(b>c?b:c);
 
 printf("the biggest no. is %d",big);
}
