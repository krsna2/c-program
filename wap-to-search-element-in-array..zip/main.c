#include <stdio.h>

int main()
{
   int i,c,e=0,n,d=0;
   printf("enter the no. of element:");
   scanf("%d",&n);
   int a[n];
    printf("enter the no. in array\n");
   for(i=0;i<n;i++)
   {
       scanf("%d",&a[i]);
       
   }
   printf("\nenter the search element:");
   scanf("%d",&c);
  
   for(i=0;i<n;i++)
   {
       if(a[i]==c)
      { e++;
       d=i;
          
      }
   }
   if(e!=0)
   {
       printf("\nfound at position %d",d);
   }
   else{
       printf("not found");
   }
}
