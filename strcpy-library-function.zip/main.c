#include<stdio.h>
#include<string.h>
int main()
{
    char s1[100];
    char s2[100];
    printf("enter first string=\n");
    scanf("%s",s1);
    printf("enter the second string=\n");
    scanf("%s",s2);
    strcpy(s2,s1);//copy value of old string to new string
    puts(s2);
    return 0;
}