#include<stdio.h>
void main()
{
    float a1,a2;

    printf("enter the first angle:");
    scanf("%f",&a1);
    
    printf("enter the second angle:");
    scanf("%f",&a2);
    
    printf("the third angle is : %f\n",180-(a1+a2));
}