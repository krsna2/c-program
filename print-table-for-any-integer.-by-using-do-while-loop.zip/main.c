
#include <stdio.h>

int main()
{
    int i = 1;
    int n;
    printf("entre any number=");
    scanf("%d",&n);
    do
    {
        printf("%d*%d=%d\n",i,n,i*n);
        i++;
    }while(i<=10);
}
