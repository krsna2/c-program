#include<stdio.h>
int
main ()
{
  int n, i, j, e = 0, d = 0;
  scanf ("%d", &n);
  int a[n][n];
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
      scanf ("%d", &a[i][j]);
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
      if (i == j)
	{
	  if (a[i][j] == 1)
	    e++;
	}
  if (e == n)
    for (i = 0; i < n; i++)
      for (j = 0; j < n; j++)
	if (i != j)
	  {
	    if (a[i][j] == 0)
	      d++;
	  }
  if (d == (n * n - n))
    printf ("identity");
  else
    printf ("not identity");
  return 0;

}

