#include<stdio.h>
void main()
{
    float s;

    printf("enter the side:");
    scanf("%f",&s);
    
    printf("the area of equilateral triangle is : %f\n",(0.434*s*s));
}