
#include <stdio.h>

int
main ()
{
  int i, sum = 0;
  printf ("the first 10 natural no. is:\n");

  for (i = 1; i <= 10; i++)
    {
      sum = sum + i;
      printf ("%d\n", i);

    }
  printf ("the sum is : %d\n", sum);
}
