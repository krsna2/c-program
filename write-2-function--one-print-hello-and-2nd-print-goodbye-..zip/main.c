#include<stdio.h>
//declaration/prototype
void printhello();
void printgoodbye();
int main(){
    printhello();//function call
    printgoodbye();//function call
    return 0;
    }
//function defination
void printhello() {
    printf("hello\n");
    }
void printgoodbye() {
    printf("goodbye\n");
}