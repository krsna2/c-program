#include <stdio.h>

void main ()
{
  float temperature,celsius;
  printf ("enter the temp. in fahrenheit=");
  scanf ("%f", &temperature);
  celsius= (temperature-32)*5/9;
  printf ("temp. in celsius=%f\n",celsius);
}

