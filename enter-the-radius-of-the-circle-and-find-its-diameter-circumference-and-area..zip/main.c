#include <stdio.h>
void main() {
    float radius,area;
    printf("enter the radius :");
scanf("%f",&radius);
area = radius*radius*3.14;
printf("the area is: %f\n",area);
printf("the diameter of the circle: %f\n",radius*2);
printf("the circumfrance is:%f\n",2*3.14*radius);
}

