
#include <stdio.h>

int main()
{
    int a;
    printf("enter the no.");
    scanf("%d",&a);
    printf("%d",(a<<5)-a);
}