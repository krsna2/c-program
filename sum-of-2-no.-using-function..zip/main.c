#include<stdio.h>
int sum(int a,int b);
int main(){
    int a,b;
     printf("enter the 1st no.=\n");
    scanf("%d",&a);
      printf("enter the 2nd no.=\n");
    scanf("%d",&b);    
    sum(a,b);
    return 0;
    }

int sum(int x,int y) {
    printf("sum = %d",x+y);
    return 0;
}



