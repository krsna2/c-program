#include <stdio.h>
void main()
{
float sub,sum,divide,a,b,mul;

printf("enter the first no.:");
scanf("%f",&a);
printf("enter the second no.:");
scanf("%f",&b);
sub =a-b;
sum=a+b;
mul=a*b;
divide=a/b;
printf("the sub is:%f\n",sub);
printf("the sum is:%f\n",sum);
printf("the mul is %f\n",mul);
printf("the div is %f\n",divide);

}


