#include <stdio.h>
void main()
{
    int n,m,rem,sum=0;
    printf("enter the no.");
    scanf("%d",&n);
    m=n;
    while(n>0)
    {
        rem=n%10;
        sum=(sum*10)+rem;
        n=n/10;
    }
    if(sum==m)
    printf("is a palindrom");
    else printf("not palindrom");
}
