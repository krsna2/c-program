
#include <stdio.h>
void main()
{
    int i,b,n,c=0;
    printf("entre the given:");
    scanf("%d",&n);
    for(i=1;n!=0;i++)
    
    {
    b=n%10; n=n/10;
    printf("%d",b);    
    }
    
}
