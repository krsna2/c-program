#include<stdio.h>
int
main ()
{
  int n,i, c = 0, d = 0;
  printf ("enter the no. of element=");
  scanf ("%d", &n);
  int a[n], b[n];
  printf("enter the no.=");
  for (i = 0; i < n; i++)
  scanf ("%d", &a[i]);

  for (i = 0; i < n; i++,c=0)
    {
      for (int j = 1; j <= a[i]; j++)
	{
	  if (a[i] % j == 0)
	    c++;

	}
      if (c == 2)
	{
	  b[d] = a[i];
	  d++;
	  
	}
      
    }
    printf("the prime no. are =");
  for (int i = 0; i < d; i++)
    printf ("%d ", b[i]);
  return 0;
}
