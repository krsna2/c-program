#include <stdio.h>

int main()
{
    int r,c,i,j,n=0;
    printf("enter the no. of elements in rows=");
    scanf("%d",&r);
    printf("enter the no. of elements in column=");
    scanf("%d",&c);
    int a[r][c];
    for(i=0;i<r;i++){
        for(j=0;j<c;j++){
            scanf("%d",&a[i][j]);
        }
    }
 for(i=0;i<r;i++){
        for(j=0;j<c;j++){
          if(a[i][j]==a[j][i]){
             n++;
          }
        }
    }
    if(n==r*c){
        printf("symmetric matrix");
    }
    else{
        printf("non-symmetric matrix");
    }
    return 0;
}

