#include <stdio.h>

int main()
{
    int n,i,j;
    printf("enter the no. of rows/column=\n");
    scanf("%d",&n);
    int a[n][n];
    printf("enter the matrix=\n");
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            
            scanf("%d",& a[i][j]);
        }
    }
    for (i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(i==j){
            printf("%d",a[i][j]);
        }
            
        }
        printf("\n");
    }
    return 0;
}

