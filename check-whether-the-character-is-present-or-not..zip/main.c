#include<stdio.h>
#include<string.h>
int main()
{
    char str[100],ch;
    int c=0,e=0;
    printf("enter the word=\n");
    scanf("%s",str);
    printf("enter the character=\n");
    scanf(" %c",&ch);
    for(int i=0;str[i]!='\0';i++){
        if(str[i]==ch){
        c++;
        }
        
    }
    if(c>0){
        printf("character is present");
        
    }
    else{
        printf("character is not present");
    }
    return 0;
}
