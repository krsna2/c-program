#include<stdio.h>
int fact(int,int);
int main(){
    int n,r;
printf("enter the n=\n");
scanf("%d",&n);
printf("enter the r==\n");
scanf("%d",&r);
fact(n,r);
return 0;}
int fact(int n,int r){
     int c=1,i;
    for(i=n;i>=1;i--)
{
    c=c*i;}
     int d=1,j;
    for(j=r;j>=1;j--){
d=d*j;}
int e=n-r,k,f=1;
for(k=1;k>=1;k--){
f=f*e;
}
printf("%d",c/(d*f));
return 0;}