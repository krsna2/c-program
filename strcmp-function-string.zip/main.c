#include<stdio.h>
#include<string.h>
int main()
{
    char s1[100];
    char s2[100];
    printf("enter first string=\n");
    scanf("%s",s1);
    printf("enter the second string=\n");
    scanf("%s",s2);
    printf("%d",strcmp(s1,s2));//compares 2 strings & return a value.
    
    return 0;
//0= both strings are equal
//positive= first>second
//negative= first<second
}
