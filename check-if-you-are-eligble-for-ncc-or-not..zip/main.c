#include <stdio.h>
int main()
{
int age;
float h,w;

printf("enter the your age=");
scanf("%d",&age);
if (age>=18)
{
printf("enter the your height=");
scanf("%f",&h);
 printf("enter the your weight=");
scanf("%f",&w);
if (h>5.8 && w>65)
{
    printf("you are eligble for NCC");
}
else{
    printf("you are not fit for NCC");
}
}
else{
    printf("you are below 18");
}
}
