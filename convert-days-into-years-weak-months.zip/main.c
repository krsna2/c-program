#include<stdio.h>
int main()
{
   int days;
   printf("Enter Days:");
   scanf("%d",&days);
   printf("Days to years %d",days/365);
   printf("\nDays to weeks %d",days/7);
   printf("\nDays to months %d",days/30);
}