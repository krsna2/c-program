#include <stdio.h>

void main()
{
    int i, n,sum=0;
    printf("enter the no.:");
    scanf("%d",&n);
     for(i=1;i<n;i++)
     { 
         if(n%i==0)
         {
         sum=sum+i;
         }
         
     }
     if (sum==n)
     printf("perfect no.");
     else 
     printf("not a perfect no.");
}
