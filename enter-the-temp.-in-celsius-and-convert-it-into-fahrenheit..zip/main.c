#include <stdio.h>

void main ()
{
  float temperature,fahrenheit;
  printf ("enter the temp. in celsius=");
  scanf ("%f", &temperature);
fahrenheit = (temperature * 9 / 5) + 32;
  printf ("temp. in fahrenheit=%f\n",fahrenheit);
}

