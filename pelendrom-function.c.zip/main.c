#include<stdio.h>
#include<math.h>
int pelendrom(int);
int main(){
    printf("enter the no.=\n");
    int n;
    scanf("%d",&n);
    pelendrom(n);
}
int pelendrom(int n){
    int rem,c=n,k=0,rev=0;
while(c!=0){
    rem=c%10;
    rev=(rev*10)+rem;
    c=c/10;

}
if(rev==n){
    printf("pelendrom");
}
else{
    printf("not pelendrom");
}
return 0;
}