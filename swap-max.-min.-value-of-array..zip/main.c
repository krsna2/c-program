#include<stdio.h>
int
main ()
{
  int n, i, max = 0, min = 0,c=0,d=0,e;
  printf ("enter the no. of elements =");
  scanf ("%d", &n);
  int arr[n];
  printf("enter the no.=\n");
  for (int i = 0; i < n; i++)
    scanf ("%d", &arr[i]);
    
  max = arr[0];
  min = arr[0];
  for (i = 0; i < n; i++)
    {
      if (arr[i] > max)
	max = arr[i];
      if (arr[i]< min)
	min = arr[i];
    }
    for(i=0;i<n;i++)
    {
        if(max==arr[i])
        c=i;
        if(arr[i]==min)
        d=i;
    }
    e=arr[c];
    arr[c]=arr[d];
    arr[d]=e;
    for(int i=0;i<n;i++)printf("%d ",arr[i]);
  
    
}


