#include <stdio.h>

int
main ()
{
  int i, j, n,sum=0;
  printf ("enter the no. of rows and column=");
  scanf ("%d", &n);
  int a[n][n];
  for (i = 0; i < n; i++)
    {
      for (j = 0; j < n; j++)
	{
	  scanf ("%d", &a[i][j]);

	}
    }
  for (i = 0; i < n; i++)
    {
      for (j = 0; j < n; j++)
	{
	  if (i > j)
	    {
	     sum=sum+a[i][j];
	    }
	}
    }
    printf("%d",sum);
}

