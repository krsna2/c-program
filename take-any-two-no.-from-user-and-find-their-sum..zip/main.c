#include <stdio.h>
int main() {
    int a,b ,sum;
    printf("enter the first no. :");
scanf("%d",&a);
printf("enter the second no. :");
scanf("%d",&b);
sum =a+b;
printf("the sum is: %d\n",sum);
}