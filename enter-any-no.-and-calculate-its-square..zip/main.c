#include<stdio.h>
int main()

{
int x;
    printf("enter the no.:");
    scanf("%d",&x);
    printf("the square is:%d\n",x*x);
    
}