#include<stdio.h>
#include<string.h>
int main()
{
    char str[100];
    gets(str);
    int length=strlen(str);
    printf("length =%d",length);
    return 0;
}