
#include <stdio.h>
void main()
{
    int i,j,n;
    printf("input number of rows for this pattern:");
    scanf("%d",&n);
    for(i=0;i<n;i++) // rows iteration 
    {
    for(j=1;j<=n-i;j++)
    printf(" "); //space reason
    for (j=1;j<=2*i-1;j++)
    {
    printf("*");
    }
    printf("\n");
}
}


