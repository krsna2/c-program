#include <stdio.h>
void main() {
    float radius,area;
    printf("enter the radius :");
scanf("%f",&radius);
area = radius*radius*3.14;
printf("the area is: %f\n",area);
}

