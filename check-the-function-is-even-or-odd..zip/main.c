#include<stdio.h>
void even();
void odd();
int main(){
    printf("enter the no.=\n");
    int n;
    scanf("%d",&n);
    if(n%2==0){
    even();}
    else{
    odd();}
    
    return 0;
    }

void even() {
    printf("even\n");
    }
void odd() {
    printf("odd\n");
}

