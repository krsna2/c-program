#include <stdio.h>

int main()
{
  int n,i,sum=0;
  float avg;
  printf("enter the no. of element=");
  scanf("%d",&n);
  int arr[n];
  for(i=0;i<n;i++)
  {
  printf("enter the %d no.",i+1);
  scanf("%d",&arr[i]);
  sum+=arr[i];
  }
  avg=(float)sum/n;
  printf("avg=%.02f",avg);
}
