#include<stdio.h>
#include<math.h>
int arm(int);
int main(){
    printf("enter the no.=\n");
    int n;
    scanf("%d",&n);
    arm(n);
}
int arm(int n){
    int rem,c,k=0,result=0;
    c=n;
while(c!=0){
    c=c/10;
k++;
}
c=n;
while(c!=0){
    rem=c%10;
    result=result+pow(rem,k);
    c=c/10;

}
if(result==n){
    printf("armstrong");
}
else{
    printf("not armstrong");
}
return 0;
}