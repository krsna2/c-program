#include<stdio.h>
void main()
{
    float b,h;

    printf("enter the base:\n");
    
    scanf("%f",&b);
    
    printf("enter the height:\n");
    scanf("%f",&h);
    
    printf("the area of tringle is:%f\n",b*h*1/2);
}