#include <stdio.h>
int main()
{
int a,b;

printf("enter the  number=");
scanf("%d",&a);
b=a%2;

if(b==0){
    printf("number is even\n");
    }

    
        else
        {
        printf("the number is odd\n");
        
    }

    return 0;
}