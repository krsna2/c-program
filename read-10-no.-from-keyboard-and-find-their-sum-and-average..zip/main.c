
#include <stdio.h>

int main()
{
  int i,sum=0,n;
  float avg;
  for (i=1;i<=10;i++)
  { 
      printf("enter the no.:");
      scanf("%d",&n);
      sum=sum+n;
  }
  printf("the sum of all value is : %d\n",sum);
  avg= sum/10.0;
  printf("the average value is :%f\n",avg);
}
