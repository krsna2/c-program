#include<stdio.h>
#include<string.h>
int main()
{
    char s1[100];
    char s2[100];
    printf("enter first string=\n");//always take the size of s1>s2.
    scanf("%s",s1);
    printf("enter the second string=\n");
    scanf("%s",s2);
    strcat(s1,s2);//concentration first string with second string.
    printf("s1=%s",s1);
    return 0;
}