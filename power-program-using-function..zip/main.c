#include<stdio.h>
int power(int ,int );
int main()
{
    int n,p;
    scanf("%d%d",&n,&p);
    printf("%d",power(n,p));
    return 0;
}
int power(int n,int p)
{
    int i,c=1;
    for(i=1;i<=p;i++)
    c*=n;
    return c;
}