#include<stdio.h>
int
main ()
{
  int r,c,i, j;
  printf ("enter the no. rows for matrix=");
  scanf ("%d", &r);
  printf ("enter the no. of column for matrix=");
  scanf ("%d", &c);
  int a[r][c], b[r][c], d[r][c];
  for (i = 0; i < r; i++)
    {
      for (j = 0; j < c; j++)
	{
	  scanf ("%d", &a[i][j]);
	}
    }
  for (i = 0; i < r; i++)
    {
      for (j = 0; j < c; j++)
	{
	  scanf ("%d", &b[i][j]);
	}
    }
    printf("sum =\n");
  for (int i = 0; i < r; i++)
    {
      for (int j = 0; j < c; j++)
	{
	  d[i][j] = a[i][j] + b[i][j];
	  printf ("%d\t ",d[i][j]);
	} printf ("\n");
    }
  return 0;
}

