#include<stdio.h>
int table(int n);
int main(){
    int n;
     printf("enter the no.=\n");
    scanf("%d",&n);
    table(n);
    return 0;
    }

int table(int x) {
    for(int i=1;i<=10;i++){
    printf("%d\n",i*x);
    }
}



