#include <stdio.h>
int main()
{
int a;

printf("enter the  number=");
scanf("%d",&a);
//increament operator:
printf("the vaule of ++a =%d\n",++a);
printf("the vaule of a++ =%d\n",a++);
//decrement operator:
printf("the vaule of --a =%d\n",--a);
printf("the vaule of a-- =%d\n",a--);


    return 0;
}