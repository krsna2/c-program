#include<stdio.h>
int main() 
{
  char a[6]={'A','d','i','t','y','a'};
  printf("name in array=");
   for (int i=0;i<6;i++)
    {
        printf(" %c",a[i]);
    }
    return 0;
}
