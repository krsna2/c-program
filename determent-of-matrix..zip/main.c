#include <stdio.h>

int
main ()
{
  int i, j, n,d;
  printf ("enter the no. of rows and column=");
  scanf ("%d", &n);
  int a[n][n];
  for (i = 0; i < n; i++)
    {
      for (j = 0; j < n; j++)
	{
	  scanf ("%d", &a[i][j]);

	}
    }
 
	 d= a[0][0]*(a[1][1]*a[2][2]-a[1][2]*a[2][1])-a[0][1]*(a[1][0]*a[2][2]-a[1][2]*a[2][0])+a[0][2]*(a[1][0]*a[2][1]-a[1][1]*a[2][0]);
	
        printf("%d",d);
}

