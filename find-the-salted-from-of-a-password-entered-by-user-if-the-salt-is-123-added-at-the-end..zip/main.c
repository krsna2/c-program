#include<stdio.h>
#include<string.h>
int main()
{
    char s1[100];
    char s2[]="123";
    printf("enter the passward =\n");
    scanf("%s",s1);
    strcat(s1,s2);
    printf("passwad after adding salt=%s",s1);
    return 0;
}
